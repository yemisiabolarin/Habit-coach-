const express = require('express');
const webpush = require('web-push');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Load VAPID keys from environment
const publicVapidKey = process.env.VAPID_PUBLIC;
const privateVapidKey = process.env.VAPID_PRIVATE;

webpush.setVapidDetails(
  'mailto:test@example.com',
  publicVapidKey,
  privateVapidKey
);

let subscriptions = [];

app.post('/subscribe', (req, res) => {
  const subscription = req.body;
  subscriptions.push(subscription);
  res.status(201).json({});
});

// Motivational messages for Yemisi
const messages = [
  { title: "Habit Coach", body: "Good morning Yemisi 🌸 — today is another chance to grow stronger. 💪🏽" },
  { title: "Habit Coach", body: "Stay strong Yemisi 💫 — replace old urges with something healthier today!" },
  { title: "Habit Coach", body: "Yemisi 🌟 — you are in control. Breathe, refocus, and choose growth." },
  { title: "Habit Coach", body: "Small steps add up Yemisi 💖 — keep pushing, you’re doing amazing!" },
  { title: "Habit Coach", body: "End your day with strength 🌙 — reflect and be proud of your progress, Yemisi." }
];

// Daily notification endpoint
app.get('/sendNotification', async (req, res) => {
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  const payload = JSON.stringify(randomMessage);

  try {
    await Promise.all(subscriptions.map(sub => webpush.sendNotification(sub, payload)));
    res.send('Random motivational notification sent ✅');
  } catch (err) {
    console.error(err);
    res.send('Error sending notifications');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

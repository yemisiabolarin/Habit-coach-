
# Yemisi Habit Coach PWA

This is your personalized habit tracker Progressive Web App (PWA) with daily push notification reminders.

## Keys
- Public VAPID Key: `BGt5cbiXzFPOmiAzS8pUfZixrQc2NJdcpmkFYzbqssgjEFvaQqhpKbayoXjYfkIo7u43PhN0SAKJBgO1umOtAzs` (already embedded in client)
- Private VAPID Key: `UOWKqPRnvXm9D2U3KL7o97uxbD0MMrAH1nPDDO9GZK8` (keep secure, add to Render environment as `VAPID_PRIVATE`)

## Deploy on Render
1. Push this project to GitHub.
2. Create a new Web Service on Render, link repo.
3. Add Environment Variables:
   - `VAPID_PUBLIC` = BGt5cbiXzFPOmiAzS8pUfZixrQc2NJdcpmkFYzbqssgjEFvaQqhpKbayoXjYfkIo7u43PhN0SAKJBgO1umOtAzs
   - `VAPID_PRIVATE` = UOWKqPRnvXm9D2U3KL7o97uxbD0MMrAH1nPDDO9GZK8
4. Build Command: `npm install`
5. Start Command: `node server.js`
6. Deploy and open your app URL.
7. Subscribe to daily reminders.

